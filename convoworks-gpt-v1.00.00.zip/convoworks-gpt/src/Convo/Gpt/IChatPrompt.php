<?php declare(strict_types=1);

namespace Convo\Gpt;


interface IChatPrompt 
{

    public function getPrompt();
}
