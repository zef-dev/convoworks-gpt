<?php declare(strict_types=1);

namespace Convo\Gpt;

class ContextLengthExceededException extends \Exception
{
}
