
# Convoworks GPT WordPress plugin

### 0.2.0 Refactor Chat App

* Refactor prompt & action interfaces
* Add validation error element
* Remove actions prompt element
* Update service template with appointment scheduling

### 0.1.0 Initial version
