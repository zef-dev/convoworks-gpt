
# Convoworks GPT WordPress plugin

### 0.3.0 Turbo Chat App

* Add chat app which uses GPT-3.5-turbo API
* Update service template with the Turbochat app example

### 0.2.0 Refactor Chat App

* Refactor prompt & action interfaces
* Add validation error element
* Remove actions prompt element
* Update service template with appointment scheduling

### 0.1.0 Initial version
